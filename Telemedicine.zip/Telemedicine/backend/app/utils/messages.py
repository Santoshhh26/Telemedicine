# Messages utility placeholder 
